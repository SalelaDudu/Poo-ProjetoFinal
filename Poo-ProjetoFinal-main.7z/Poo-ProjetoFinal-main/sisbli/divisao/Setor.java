package divisao;

public class Setor {
  
    private String nome;

    public Setor(String nome){
        this.nome = nome;
    }

    public String getNome(){
        return nome;
    }
}
