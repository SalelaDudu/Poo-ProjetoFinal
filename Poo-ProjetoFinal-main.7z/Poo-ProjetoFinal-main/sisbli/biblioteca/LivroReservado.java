package biblioteca;

public interface LivroReservado {
    public void ocorreu(Reserva reserva);
    public String informarReserva();    
}
