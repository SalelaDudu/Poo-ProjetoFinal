package infraestrutura;

public class Util {
    
}
