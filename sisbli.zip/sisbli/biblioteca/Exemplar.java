package biblioteca;

public class Exemplar {
    
}
