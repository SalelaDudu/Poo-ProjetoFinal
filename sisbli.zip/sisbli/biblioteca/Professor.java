package biblioteca;

public class Professor {
    
}
