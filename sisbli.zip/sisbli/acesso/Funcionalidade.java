package acesso;

public class Funcionalidade {
    
}
