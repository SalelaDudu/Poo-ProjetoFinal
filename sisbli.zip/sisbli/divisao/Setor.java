package divisao;

public class Setor {
    
}
