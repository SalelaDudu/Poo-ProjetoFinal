package acesso;

public class Usuario {
    
}
