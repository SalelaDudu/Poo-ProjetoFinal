import javax.swing.JOptionPane;
import infraestrutura.Util;
@SuppressWarnings("unused")
public class Principal {
    // ATENCAO  REMOVER TODOS OS COMENTARIOS ANTES DE ENVIAR PARA O CAYO
    public static void main(String[] args){
        // String que recebe o título da janeal do programa
        String titulo_programa = "Sistema Bibliotecário | v0.1";        

        // Recebe o login do usuario
        // String usuario_login = JOptionPane.showInputDialog(null,"Informe seu login:",titulo_programa,JOptionPane.PLAIN_MESSAGE);
        // String usuario_senha = JOptionPane.showInputDialog(null,"Informe sua senha:",titulo_programa,JOptionPane.PLAIN_MESSAGE);

        // Encerra o programa
        System.exit(0);
    }
    
}