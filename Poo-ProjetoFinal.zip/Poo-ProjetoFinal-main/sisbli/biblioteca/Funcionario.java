package biblioteca;

public class Funcionario {
    
}
