package biblioteca;

public class LivroReservado {
    
}
