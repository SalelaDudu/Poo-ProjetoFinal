package biblioteca;

public class Bibliotecario {
    
}
