package biblioteca;

public class Livro {
    
}
